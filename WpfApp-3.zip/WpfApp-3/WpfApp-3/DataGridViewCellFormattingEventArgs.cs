﻿namespace WpfApp_3
{
    internal class DataGridViewCellFormattingEventArgs
    {
        public int RowIndex { get; internal set; }
    }
}