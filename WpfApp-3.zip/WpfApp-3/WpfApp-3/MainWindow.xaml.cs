﻿using System.Collections.Generic;
using System.Drawing;
using System.Windows;

namespace WpfApp_3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        public MainWindow()
        {
            InitializeComponent();
            List<Employee> users = new List<Employee>();
            users.Add(new Employee() { Id = 1, FirstName = "Sangavi", LastName = "R", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 2, FirstName = "Siddhartha", LastName = "Gupta", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 3, FirstName = "Hrishikesh", LastName = "K", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 4, FirstName = "Barinder", LastName = "Singh", DeptName = "DPS", IsActive = false });
            users.Add(new Employee() { Id = 5, FirstName = "Sumithra", LastName = "Thavadan", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 6, FirstName = "Usha", LastName = "S", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 7, FirstName = "Jhanavi", LastName = "K", DeptName = "DPS", IsActive = false });
            users.Add(new Employee() { Id = 8, FirstName = "Manish", LastName = "Sharma", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 9, FirstName = "Prachi", LastName = "Mishra", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 10, FirstName = "Keerthana", LastName = "A", DeptName = "DPS", IsActive = false });
            users.Add(new Employee() { Id = 11, FirstName = "Swatish", LastName = "Reddy", DeptName = "DPS", IsActive = false });
            users.Add(new Employee() { Id = 12, FirstName = "Pritham", LastName = "Singh", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 13, FirstName = "Deepika", LastName = "S", DeptName = "DPS", IsActive = false });
            users.Add(new Employee() { Id = 14, FirstName = "Lokesh", LastName = "M", DeptName = "DPS", IsActive = true });
            users.Add(new Employee() { Id = 15, FirstName = "Rajesh", LastName = "R", DeptName = "DPS", IsActive = false });
           
            DataGridView.ItemsSource = users;
        }
        private class Employee
        {
            public int Id { set; get; }
            public string FirstName { set; get; }
            public string LastName { set; get; }
            public string DeptName { set; get; }
            public bool IsActive { set; get; }

        }
    }
}

