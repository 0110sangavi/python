﻿namespace WpfApp_5
{
    public class DataGridViewCellPaintingEventArgs
    {
    }
}